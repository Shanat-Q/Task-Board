import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Document, Page, pdfjs } from 'react-pdf';
import './App.css';

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

const MockAPIUpload = (file) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const response = {
        filePath: '/path/to/your/uploaded/file.pdf',
        status: 'success',
      };
      resolve(response);
    }, 2000); 
  });
};

const App = () => {
  const [file, setFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [numPages, setNumPages] = useState(null);

  const onDrop = async (acceptedFiles) => {
    const selectedFile = acceptedFiles[0];

    if (selectedFile.type !== 'application/pdf') {
      setUploadStatus('error');
      return;
    }

    setFile(selectedFile);
    setUploadStatus('uploading');

    try {
      const response = await MockAPIUpload(selectedFile);
      setUploadStatus(response.status);
    } catch (error) {
      setUploadStatus('error');
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: '.pdf',
    onDrop,
  });

  const onDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
  };

  return (
    <div className="App">
      <div {...getRootProps()} className="dropzone">
        <input {...getInputProps()} />
        {file ? (
          <Document file={file} onLoadSuccess={onDocumentLoadSuccess}>
            {Array.from(new Array(numPages), (el, index) => (
              <Page key={`page_${index + 1}`} pageNumber={index + 1} />
            ))}
          </Document>
        ) : (
          <p>Drag & drop your e-bill PDF file here, or click to select one.</p>
        )}
      </div>
      {uploadStatus && (
        <div className={`upload-status ${uploadStatus}`}>
          {uploadStatus === 'uploading' && <span>Uploading...</span>}
          {uploadStatus === 'success' && <span>Upload successful!</span>}
          {uploadStatus === 'error' && <span>Upload failed. Please try again.</span>}
        </div>
      )}
    </div>
  );
};

export default App;
