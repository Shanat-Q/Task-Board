import './Expenseitem.css';

function Expenseitem() {
    
    return(
        <div className="expense-item">
            <div>Select</div>

        <div className="expense-item__description">
                <h2>Black Polo</h2>
                <h2>BlUE Polo</h2>
                <h2>Black Hoodie</h2>
                <h2>Pink Round</h2>
                <div className="expense-item__price">2294/-</div>
                <div className="expense-item__price">2394/-</div>
                <div className="expense-item__price">3947/-</div>
                <div className="expense-item__price">4694/-</div>
            </div>
        </div>
    );
}

export default Expenseitem;